import dao.CrimeAnalysisServiceImpl;
import dao.ICrimeAnalysisService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import entity.Incident;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class CrimeAnalysisServiceTest {
    private ICrimeAnalysisService service;

    @BeforeEach
    void setUp() {
        // Initialize service implementation
        service = new CrimeAnalysisServiceImpl();
    }

    @Test
    void testCreateIncident() {
        Incident incident = new Incident(60, "Robbery", new Date(), "City Center, Nagpur", "Bank heist", "Open", 1, 1, 1);
        assertTrue(service.createIncident(incident), "Incident should be created successfully.");
    }

    @Test
    void testUpdateIncidentStatus() {
        assertTrue(service.updateIncidentStatus("Closed", 1), "Status should be updated successfully.");
    }
}
