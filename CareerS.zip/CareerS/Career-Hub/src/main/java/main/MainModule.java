package main;

import dao.JobBoardDAOImpl;
import entity.*;
import exception.*;
import util.DBConnUtil;

import java.sql.Date;
import java.util.List;
import java.util.Scanner;

public class MainModule {
    private static JobBoardDAOImpl dao = new JobBoardDAOImpl();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        try {
            dao.initializeDatabase();
        } catch (DatabaseConnectionException e) {
            System.out.println("Error initializing database: " + e.getMessage());
            return;
        }

        while (true) {
            displayMenu();
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            try {
                switch (choice) {
                    case 1: // Add Company
                        addCompany();
                        break;
                    case 2: // Post Job
                        postJob();
                        break;
                    case 3: // Add Applicant
                        addApplicant();
                        break;
                    case 4: // Apply for Job
                        applyForJob();
                        break;
                    case 5: // List Job Listings
                        listJobListings();
                        break;
                    case 6: // List Companies
                        listCompanies();
                        break;
                    case 7: // List Applicants
                        listApplicants();
                        break;
                    case 8: // List Applications for Job
                        listApplicationsForJob();
                        break;
                    case 9: // Calculate Average Salary
                        calculateAverageSalary();
                        break;
                    case 10: // Search Jobs by Salary Range
                        searchJobsBySalaryRange();
                        break;
                    case 11: // Exit
                        System.out.println("Exiting...");
                        DBConnUtil.closeConnection(null);
                        scanner.close();
                        System.exit(0);
                    default:
                        System.out.println("Invalid choice");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private static void displayMenu() {
        System.out.println("\nCareerHub");
        System.out.println("1. Add Company");
        System.out.println("2. Post Job");
        System.out.println("3. Add Applicant");
        System.out.println("4. Apply for Job");
        System.out.println("5. List Job Listings");
        System.out.println("6. List Companies");
        System.out.println("7. List Applicants");
        System.out.println("8. List Applications for Job");
        System.out.println("9. Calculate Average Salary");
        System.out.println("10. Search Jobs by Salary Range");
        System.out.println("11. Exit");
        System.out.print("Enter your choice: ");
    }

    private static void addCompany() throws DatabaseConnectionException {
        System.out.print("Enter Company Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Location: ");
        String location = scanner.nextLine();
        Company company = new Company(0, name, location);
        dao.insertCompany(company);
        System.out.println("Company added successfully");
    }

    private static void postJob() throws DatabaseConnectionException {
        System.out.print("Enter Company ID: ");
        int companyID = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter Job Title: ");
        String jobTitle = scanner.nextLine();
        System.out.print("Enter Job Description: ");
        String jobDesc = scanner.nextLine();
        System.out.print("Enter Job Location: ");
        String jobLocation = scanner.nextLine();
        System.out.print("Enter Salary: ");
        double salary = scanner.nextDouble();
        scanner.nextLine();
        System.out.print("Enter Job Type (Full-time/Part-time/Contract): ");
        String jobType = scanner.nextLine();
        JobListing job = new JobListing(0, companyID, jobTitle, jobDesc, jobLocation, salary, jobType, new Date(System.currentTimeMillis()));
        dao.insertJobListing(job);
        System.out.println("Job posted successfully");
    }

    private static void addApplicant() throws DatabaseConnectionException, InvalidEmailFormatException, FileUploadException {
        System.out.print("Enter First Name: ");
        String firstName = scanner.nextLine();
        System.out.print("Enter Last Name: ");
        String lastName = scanner.nextLine();
        System.out.print("Enter Email: ");
        String email = scanner.nextLine();
        System.out.print("Enter Phone: ");
        String phone = scanner.nextLine();
        System.out.print("Enter Resume File Path: ");
        String resume = scanner.nextLine();
        if (!resume.endsWith(".pdf")) {
            throw new FileUploadException("Unsupported file format. Only PDF allowed.");
        }
        Applicant applicant = new Applicant(0, firstName, lastName, email, phone, resume);
        dao.insertApplicant(applicant);
        System.out.println("Applicant added successfully");
    }

    private static void applyForJob() throws DatabaseConnectionException, ApplicationDeadlineException {
        System.out.print("Enter Job ID: ");
        int jobID = scanner.nextInt();
        System.out.print("Enter Applicant ID: ");
        int applicantID = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter Cover Letter: ");
        String coverLetter = scanner.nextLine();
        JobApplication application = new JobApplication(0, jobID, applicantID, new Date(System.currentTimeMillis()), coverLetter);
        dao.insertJobApplication(application);
        System.out.println("Application submitted successfully");
    }

    private static void listJobListings() throws DatabaseConnectionException {
        List<JobListing> jobs = dao.getJobListings();
        jobs.forEach(job -> System.out.println(job.getJobTitle() + " - " + job.getCompanyID() + " - " + job.getSalary()));
    }

    private static void listCompanies() throws DatabaseConnectionException {
        List<Company> companies = dao.getCompanies();
        companies.forEach(company -> System.out.println(company.getCompanyName() + " - " + company.getLocation()));
    }

    private static void listApplicants() throws DatabaseConnectionException {
        List<Applicant> applicants = dao.getApplicants();
        applicants.forEach(applicant -> System.out.println(applicant.getFirstName() + " " + applicant.getLastName() + " - " + applicant.getEmail()));
    }

    private static void listApplicationsForJob() throws DatabaseConnectionException {
        System.out.print("Enter Job ID: ");
        int jobID = scanner.nextInt();
        List<JobApplication> applications = dao.getApplicationsForJob(jobID);
        applications.forEach(app -> System.out.println("Applicant ID: " + app.getApplicantID() + " - Date: " + app.getApplicationDate()));
    }

    private static void calculateAverageSalary() throws DatabaseConnectionException, NegativeSalaryException {
        double avgSalary = dao.calculateAverageSalary();
        System.out.println("Average Salary: " + avgSalary);
    }

    private static void searchJobsBySalaryRange() throws DatabaseConnectionException {
        System.out.print("Enter Minimum Salary: ");
        double minSalary = scanner.nextDouble();
        System.out.print("Enter Maximum Salary: ");
        double maxSalary = scanner.nextDouble();
        List<JobListing> jobs = dao.getJobsBySalaryRange(minSalary, maxSalary);
        jobs.forEach(job -> System.out.println(job.getJobTitle() + " - " + job.getSalary()));
    }
}
